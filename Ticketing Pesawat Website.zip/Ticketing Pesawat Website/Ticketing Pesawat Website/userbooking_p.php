<?php
include "koneksi.php";

$code   = $_POST['code_tiket'];
$w_book   = $_POST['waktu_booking'];
$full  = $_POST['full_name'];
$w_berangkat = $_POST['waktu_berangkat'];
$bandara_a = $_POST['bandara_awal'];
$bandara_t   = $_POST['bandara_tujuan'];
$name  = $_POST['nama_pesawat'];
$class  = $_POST['class_penerbangan'];
$status = 'Proses';
$harga = $_POST['harga'];


$sql    = 'INSERT INTO table_booking(code_tiket, waktu_booking, full_name, waktu_berangkat, bandara_awal, bandara_tujuan, nama_pesawat, class_penerbangan, status, harga) VALUES ("'.$code.'", "'.$w_book.'", "'.$full.'", "'.$w_berangkat.'", "'.$bandara_a.'", "'.$bandara_t.'", "'.$name.'", "'.$class.'", "'.$status.'", "'.$harga.'") ';
$query  = mysqli_query($connect, $sql);

if($query) {
    echo "<script>window.alert('Selamat, anda berhasil booking penerbangan'); window.location.href='cart.php';</script>";
} else {
    echo "<script>window.alert('Oops!!, Terjadi kesalahan!!!'); window.location.href='userindex.php';</script>";
}
?>