<?php
    include "koneksi.php";

    $user   = $_POST['username'];
    $full   = $_POST['full_name'];
    $email  = $_POST['email'];
    $address = $_POST['address'];
    $gender = $_POST['jenis_kelamin'];
    $pass   = $_POST['password'];

    $sql = mysqli_query($connect, 'update table_user set username="'.$user.'", full_name="'.$full.'", email="'.$email.'", address="'.$address.'", jenis_kelamin="'.$gender.'", password="'.$pass.'" where username="'.$user.'" ');
    
    if($sql) {
        echo "<script>window.alert('Data user berhasil di Edit');window.location.href='profile.php';</script>";
    } else {
        echo "<script>window.alert('Data Gagal');window.close();</script>";
    }
?>