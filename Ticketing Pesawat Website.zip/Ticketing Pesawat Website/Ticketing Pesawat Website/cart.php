<?php
include "session.php";


    //ubah timezone menjadi jakarta
    date_default_timezone_set("Asia/Jakarta");

    // $user = "Crosby";
    //ambil jam dan menit
    $jam = date('H:i');

    //atur salam menggunakan IF
    if ($jam > '05:30' && $jam < '11:59') {
        $salam = 'Morning';
    } elseif ($jam >= '12:00' && $jam < '17:00') {
        $salam = 'Afternoon';
    } elseif ($jam >= '17:01' && $jam < '20:00') {
        $salam = 'Evening';
    } else {
        $salam = 'Night';
    }

    // option bandara
    $arrstate = array
    (
        'AK' => 'Alaska',
        'AL' => 'Alabama',
        'AR' => 'Arkansas',
        'AZ' => 'Arizona'   
    );

    // random code reservation
    $permitted_chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    function generate_string($input, $strength = 16) {
    $input_length = strlen($input);
    $random_string = '';
    for($i = 0; $i < $strength; $i++) {
        $random_character = $input[mt_rand(0, $input_length - 1)];
        $random_string .= $random_character;
    }
        return $random_string;
    }

    $planes = array('Boeing 777-300ER','Airbus A330-300','Airbus A330-200','Airbus A330-900neo','Boeing 737 Max 8','BOEING 737-800NG','ATR 72-600');
    $plane  = array_rand($planes);
?>


<!DOCTYPE html>
<html lang="en">

    <head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Garuda Indonesia</title>

    <!-- Favico<img src="..." class="rounded mx-auto d-block" alt="...">ns -->
    <link href="assets/img/garudaindonesia.png" rel="icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
    </head>

    <body class="d-flex flex-column h-100">

        <!-- ======= Header ======= -->
        <header id="header">
            <div class="container d-flex align-items-center justify-content-between">
            <a href="index.html" class="logo"><img src="assets/img/logogaruda.png" alt="" class="img-fluid"></a>
            <nav id="navbar" class="navbar">
                <ul>
                <?php include "koneksi.php";
                    $ss = mysqli_query($connect,'select * from table_user where username="'.$_SESSION['table_user'].'" ');
                    $ds = mysqli_fetch_array($ss);
                    ?>
                    <li class="dropdown"><a href="#"><?= $ds['username']; ?></a>
                        <ul>
                            <li><a href="profile.php">Profile<i class="fas fa-user"></i></a></li>
                            <li></i><a class="scrollto" href="sign_out.php">Sign Out<i class="fas fa-sign-out"></i></a></li>
                        </ul>
                    </li>
                    <li><a class="nav-link scrollto" href="home.php"><span>Home</span><i class="fas fa-home"></i></a></li>
            <li><a class="nav-link scrollto" href="userindex.php"><span>Booked</span><i class="fas fa-book-open"></i></a></li>
            <li><a class="nav-link scrollto active" href="cart.php"><span>Cart</span><i class="fas fa-shopping-cart"></i></a></li>
            <li><a class="nav-link scrollto" href="searchdepart.php"><span>Search Depart</span><i class="fas fa-plane-departure"></i></a></li>
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
            </nav><!-- .navbar -->
            </div>
        </header><!-- End Header -->
        
        <main id="main" class="mb-5 pb-5 mt-3"> <!--Content -->
            <div class="text-center">
                <p class="fs-3"><?= ' Good '.$salam.' '.$ds['username']; ?></p>
            </div>
            <marquee directio="left" scrollamount="15" class="mb-2 mx-lg-5">Selamat, Datang di Website Ticketing Garuda Indonesia Airlines</marquee>
            
            <div class="container">
                <div class="d-flex-inline ">
                    <h3>Your Cart</h3>
                </div>
            </div>

            <!-- CARD STATUS-->
            <?php include "koneksi.php";
                            $sql = mysqli_query($connect, 'select * from table_booking ');
                            while($dtt = mysqli_fetch_array($sql) ) {
                            ?>
            <div class="container mt-3">
                <div class="card text-dark bg-info mb-3" style="max-width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title fw-bold text-light">Code Ticket</h5>
                        <p class="card-text"><?=$dtt['code_tiket'];?></p>
                        <h5 class="card-title fw-bold text-light">Status</h5>
                        
                                <?php
                                    if($dtt['status'] === 'accepted'){?>
                                        <p class="card-text text-success"><?=$dtt['status'];?></p>
                                        <?php } else if ($dtt['status'] === 'refused') {
                                            ?>
                                            <p class="card-text" style="color: red;"><?=$dtt['status'];?></p> <?php } else{?>
                                                <p class="card-text"><?=$dtt['status'];?></p><?php } ?>
                    </div>
                </div>
            </div>
            <?php }?>
        </main>

    
        <!-- Footer -->
        <footer id="footer" class="bd-footer mt-5 clearfix">
            <div class="fixed-bottom p-3 bg-white d-flex justify-content-center clearfix">
                <div class="copyright ">
                    &copy; Copyright <strong><span>Team 4 MDPL Praktik</span></strong>
                </div>
            </div>
        </footer><!-- End Footer -->


        <!-- Vendor JS Files -->
        <script src="assets/vendor/purecounter/purecounter.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
        <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
        <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
        <script src="assets/vendor/php-email-form/validate.js"></script>

        <!-- Template Main JS File -->
        <script src="assets/js/main.js"></script>

    </body>

</html>