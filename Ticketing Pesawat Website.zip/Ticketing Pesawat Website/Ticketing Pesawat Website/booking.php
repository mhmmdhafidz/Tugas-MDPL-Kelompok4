<?php
include "koneksi.php";

$ambildata = mysqli_query($connect, "select * from table_tiket");
$tampil = mysqli_fetch_array($ambildata);

$user   = $tampil['code_tiket'];
$full   = $tampil['depart'];
$email  = $tampil['bandara_awal'];
$address = $tampil['bandara_tujuan'];
$gender = $tampil['nama_pesawat'];
$pass   = $tampil['class_penerbangan'];

$sql    = 'INSERT INTO table_user(code_tiket, full_name, waktu_berangkat, address, jenis_kelamin, password) VALUES ("'.$user.'", "'.$full.'", "'.$email.'", "'.$address.'", "'.$gender.'", "'.$pass.'") ';
$query  = mysqli_query($connect, $sql);

if($query) {
    echo "<script>window.alert('Selamat, Akun anda berhasil dibuat'); window.location.href='sign_in.php';</script>";
} else {
    echo "<script>window.alert('Oops!!, Terjadi kesalahan!!!'); window.location.href='sign_up.php';</script>";
}
?>