<?php
    usleep(500000);
    require '../function.php';

    $keyword = $_GET["keyword"];
    $query = "SELECT * FROM table_user WHERE
                -- LIKE berguna untuk mencari data bisa nama depan, huruf , bebas
                username        LIKE '%$keyword%' OR
                full_name       LIKE '%$keyword%' OR
                email           LIKE '%$keyword%' OR
                address         LIKE '%$keyword%' OR
                jenis_kelamin   LIKE '%$keyword%'
                

            ";

    $game    = query($query);
?>
    <table border="1" cellpadding="10" cellspacing="0">
            
        <tr>
        <th>No</th>
        <th>Image</th>
        <th>Name</th>
        <th>Username</th>
        <th>Email</th>
        <th>Address</th>
        <th>Gender</th>
        <th colspan="2">Action</th>
        </tr>
        <?php $i = 1; ?>
            <?php foreach ($game as $row) :?>
            <tr>
                <td><?= $i ?></td>
                <td><img src="img/<?= $row["image"]; ?>" width="50"></td>
                <td><?= $row["full_name"]?></td>
                <td><?= $row["username"]?></td>
                <td><?= $row["email"]?></td>
                <td><?= $row["address"]?></td>
                <td><?= $row["jenis_kelamin"]?></td>
                <td>
                <a href="edituser.php?kode=<?= $row["id_user"]; ?>">
                                        <button type="button" class="btn btn-warning">
                                            <i class="fas fa-pencil"></i>
                                        </button>
                                    </a>
                                    <a href="?kode=<?= $row["username"]; ?>">
                                        <button type="button" class="btn btn-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </a>
                </td>
            </tr>
            <?php $i++; ?>
            <?php endforeach;?>
    
    </table>