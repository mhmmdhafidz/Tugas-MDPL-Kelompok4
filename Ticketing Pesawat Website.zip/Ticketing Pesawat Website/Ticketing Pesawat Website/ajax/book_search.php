<?php
    usleep(500000);
    require '../function_bookdash.php';

    $keyword = $_GET["keyword"];
    $query = "SELECT * FROM table_booking WHERE
                -- LIKE berguna untuk mencari data bisa nama depan, huruf , bebas
                code_tiket          LIKE '%$keyword%' OR
                waktu_booking       LIKE '%$keyword%' OR
                full_name           LIKE '%$keyword%' OR
                waktu_berangkat     LIKE '%$keyword%' OR
                bandara_awal        LIKE '%$keyword%' OR
                bandara_tujuan      LIKE '%$keyword%' OR
                nama_pesawat        LIKE '%$keyword%' OR
                class_penerbangan   LIKE '%$keyword%'d=


                
                

            ";

    $game    = query($query);
?>
    <table border="1" cellpadding="10" cellspacing="0">
            
        <tr>
        <th>No</th>
        <th>Code Ticket</th>
        <th>Name</th>
        <th>Depart</th>
        <th>From</th>
        <th>To</th>
        <th>Class</th>
        <th>Plane</th>
        <th colspan="2">Action</th>
        </tr>
        <?php $i = 1; ?>
            <?php foreach ($game as $row) :?>
            <tr>
                <td><?= $i ?></td>
                <td><?= $row["code_tiket"]?></td>
                <td><?= $row["full_name"]?></td>
                <td><?= $row["waktu_booking"]?></td>
                <td><?= $row["bandara_awal"]?></td>
                <td><?= $row["bandara_tujuan"]?></td>
                <td><?= $row["nama_pesawat"]?></td>
                <td><?= $row["class_penerbangan"]?></td>
                <td>
                <?php 
                                    if($row['status']=='Proses') {
                                    ?>
                                    <a href="terimabooking.php?code_tiket=<?=$row['code_tiket'];?>" onclick="return confirm('Ingin memproses??');" class="white-text">
                                        <button type="button" class="btn btn-primary">
                                            <i class="fas fa-check"></i>
                                        </button>
                                    </a>
                                    
                                    <?php 
                                    } 
                                    ?>
                <?php 
                                    if($row['status']=='Proses') {
                                    ?>
                                    <a href="tolakbooking.php?code_tiket=<?=$row['code_tiket'];?>" onclick="return confirm('Ingin membatalkan?');" class="white-text">
                                        <button type="button" class="btn btn-danger" >
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </a>
                                    
                                    <?php 
                                    } else {
                                        echo $row['status'];
                                    }?>
            </tr>
            <?php $i++; ?>
            <?php endforeach;?>
    
    </table>