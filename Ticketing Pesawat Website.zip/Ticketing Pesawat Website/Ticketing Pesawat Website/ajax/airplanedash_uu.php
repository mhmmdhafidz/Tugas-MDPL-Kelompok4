<?php
    usleep(500000);
    require '../function_air.php';

    $keyword = $_GET["keyword"];
    $query = "SELECT * FROM table_pesawat WHERE
                -- LIKE berguna untuk mencari data bisa nama depan, huruf , bebas
                code_pesawat        LIKE '%$keyword%' OR
                type_pesawat       LIKE '%$keyword%' OR
                capacity           LIKE '%$keyword%'

                

            ";

    $game    = query($query);
?>
    <table border="1" cellpadding="10" cellspacing="0">
            
        <tr>
        <th>No</th>
        <th>Airplane Code</th>
        <th>Type</th>
        <th>Capacity</th>
        <th colspan="2" style="text-align: center;">Action</th>
        </tr>
        <?php $i = 1; ?>
            <?php foreach ($game as $row) :?>
            <tr>
                <td><?= $i ?></td>
                <td><?= $row["code_pesawat"]?></td>
                <td><?= $row["type_pesawat"]?></td>
                <td><?= $row["capacity"]?></td>
                <td>
                <a href="editairplane.php?kode=<?= $row["code_pesawat"]; ?>">
                        <button type="button" class="btn btn-success">
                        <i class="fas fa-pencil"></i>
                        </button>
                        </a>
                        <a href="?kode=<?= $row["code_pesawat"]; ?>">
                                        <button type="button" class="btn btn-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </a>
                </td>
            </tr>
            <?php $i++; ?>
            <?php endforeach;?>
    
    </table>