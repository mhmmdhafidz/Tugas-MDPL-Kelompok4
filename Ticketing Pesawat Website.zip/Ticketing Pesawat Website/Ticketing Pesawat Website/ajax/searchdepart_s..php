<?php
    usleep(500000);
    require '../function_searchdepart.php';

    $keyword = $_GET["keyword"];
    $query = "SELECT * FROM table_tiket WHERE
                -- LIKE berguna untuk mencari data bisa nama depan, huruf , bebas
                code_tiket          LIKE '%$keyword%' OR
                depart              LIKE '%$keyword%' OR
                bandara_awal        LIKE '%$keyword%' OR
                bandara_tujuan      LIKE '%$keyword%' OR
                nama_pesawat        LIKE '%$keyword%' OR
                class_penerbangan   LIKE '%$keyword%' OR

                
                

            ";

    $game    = query($query);
?>
    <table border="1" cellpadding="10" cellspacing="0">
            
        <tr>
        <th>No</th>
        <th>Depart</th>
        <th>From</th>
        <th>To</th>
        <th>Class</th>
        <th>Pesawat</th>
        <th>Book</th>
        </tr>
        <?php $i = 1; ?>
            <?php foreach ($game as $row) :?>
            <tr>
                <td><?= $i ?></td>
                <td><?= $row["depart"]?></td>
                <td><?= $row["bandara_awal"]?></td>
                <td><?= $row["bandara_tujuan"]?></td>
                <td><?= $row["class_penerbangan"]?></td>
                <td><?= $row["nama_pesawat"]?></td>

                
                
                <td>
                    <a href="userindex_edit.php?kode=<?= $row["code_tiket"]; ?>">
                                <button type="button" class="btn btn-info">
                                    <i class="fas fa-book-open"></i>
                                </button>
            </td>
            </tr>
            <?php $i++; ?>
            <?php endforeach;?>
    
    </table>