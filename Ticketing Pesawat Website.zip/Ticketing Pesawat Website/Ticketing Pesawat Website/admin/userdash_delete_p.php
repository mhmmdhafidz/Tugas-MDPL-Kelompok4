<?php
//     include "koneksi.php";

//     $username = $_GET['username'];

//     $sql = mysqli_query($connect, 'delete from table_user where username="'.$username.'" ');

// if($sql) {
//     echo "<script>window.alert('Data berhasil dihapus');window.location.href='userdash.php';</script>";
// } else {
//     echo "<script>window.alert('Gagal tuk Hapus');window.close();</script>";

// }




        
?>