<?php
include "session.php";


    //ubah timezone menjadi jakarta
    date_default_timezone_set("Asia/Jakarta");

    $user = "Admin";
    //ambil jam dan menit
    $jam = date('H:i');

    //atur salam menggunakan IF
    if ($jam > '05:30' && $jam < '11:59') {
        $salam = 'Morning';
    } elseif ($jam >= '12:00' && $jam < '17:00') {
        $salam = 'Afternoon';
    } elseif ($jam >= '17:01' && $jam < '20:00') {
        $salam = 'Evening';
    } else {
        $salam = 'Night';
    }
?>


<!DOCTYPE html>
<html lang="en">

    <head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Garuda Indonesia</title>

    <!-- Favico<img src="..." class="rounded mx-auto d-block" alt="...">ns -->
    <link href="../assets/img/garudaindonesia.png" rel="icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Template Main CSS File -->
    <link href="../assets/css/style.css" rel="stylesheet">
    </head>

    <body class="d-flex flex-column h-100">

        <!-- ======= Header ======= -->
        <header id="header">
            <div class="container d-flex align-items-center justify-content-between">
            <a href="index.html" class="logo"><img src="../assets/img/logogaruda.png" alt="" class="img-fluid"></a>
            <nav id="navbar" class="navbar">
                <ul>
                <li class="dropdown"><a href="#"><?= $user; ?></a></li>
                    <li><a class="nav-link scrollto" href="index.php"><span>Dashboard</span><i class="fas fa-tachometer-alt"></i></a></li>
                    <li><a class="nav-link scrollto" href="userdash.php"><span>User</span><i class="fas fa-user"></i></a></li>
                    <li><a class="nav-link scrollto" href="bookdash.php"><span>Booked</span><i class="far fa-calendar-alt"></i></a></li>
                    <li><a class="nav-link scrollto active" href="airplanedash.php"><span>Airlines</span><i class="fas fa-plane-departure"></i></a></li>
                    <li><a class="nav-link scrollto" href="tiket.php"><span>Ticket</span><i class="fas fa-ticket"></i></a></li>
                    <li><a class="nav-link scrollto" href="sign_out.php">Sign Out<i class="fas fa-sign-out"></i></a></li>
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
            </nav><!-- .navbar -->
            </div>
        </header><!-- End Header -->
        
        <main id="main" class="mb-5 pb-5 mt-3"> <!--Content -->           
            <div class="container mb-3">
                <div class="d-flex justify-content-center">
                    <h3 class="fw-bold">Airplane Edit</h3>
                </div>
            </div>

            <!-- CARD STATUS-->
            <div class="container">
            
                    <?php
                    include "koneksi.php";
                    $sql = mysqli_query($connect, "select * from table_pesawat where code_pesawat='$_GET[kode]'");
                    $data = mysqli_fetch_array($sql);
                
                    
                    ?>
                <form class="row g-3 needs-validation" method="POST" action="editairplane_p.php"  novalidate>
                    <div class="col-md-4">
                        <label for="fromdepart" class="form-label">Airplane Code</label>
                        <input type="text"  class="form-control"  readonly value="<?php echo $data['code_pesawat']; ?>" name="code_pesawat"  >
                    </div>

                    <div class="col-md-4">
                        <label for="todepart" class="form-label">Airplane Type</label>
                        <input type="text"  class="form-control"  name="type_pesawat" value="<?php echo $data['type_pesawat']; ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="typeplane" class="form-label">Capacity</label>
                        <input type="text"  class="form-control"  value="<?php echo $data['capacity']; ?>" name="capacity" >
                    </div>
                    <div class="col d-flex justify-content-center mt-5">
                        <a href="editairplane_p.php?kode=<?= $row["code_pesawat"]; ?>">
                        <button class="btn btn-primary" type="submit">Save</button>

                        </a>
                    </div>
                </form>
            </div>
        </main>

    
        <!-- Footer -->
        <footer id="footer" class="bd-footer mt-5 clearfix">
            <div class="fixed-bottom p-3 bg-white d-flex justify-content-center clearfix">
                <div class="copyright ">
                    &copy; Copyright <strong><span>Team 4 MDPL Praktik</span></strong>
                </div>
            </div>
        </footer><!-- End Footer -->


        <!-- Vendor JS Files -->
        <script src="../assets/vendor/purecounter/purecounter.js"></script>
        <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
        <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
        <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
        <script src="../assets/vendor/php-email-form/validate.js"></script>

        <!-- Template Main JS File -->
        <script src="../assets/js/main.js"></script>

    </body>

</html>