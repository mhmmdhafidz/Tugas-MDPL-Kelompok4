<?php
include "koneksi.php";
include "session.php";

$code = $_GET['code_tiket'];

$status = 'refused';

$sql = mysqli_query($connect, 'update table_booking set status="'.$status.'" where code_tiket="'.$code.'" ');
if($sql) {
    echo "<script>window.alert('Transaksi telah berhasil di cancel');window.location.href='bookdash.php';</script>";
} else {
    echo "<script>window.alert('Terjadi ERROR!!');window.location.href='bookdash.php';</script>";
}
?>