<?php
include "session.php";


    //ubah timezone menjadi jakarta
    date_default_timezone_set("Asia/Jakarta");

    $user = "Admin";
    //ambil jam dan menit
    $jam = date('H:i');

    //atur salam menggunakan IF
    if ($jam > '05:30' && $jam < '11:59') {
        $salam = 'Morning';
    } elseif ($jam >= '12:00' && $jam < '17:00') {
        $salam = 'Afternoon';
    } elseif ($jam >= '17:01' && $jam < '20:00') {
        $salam = 'Evening';
    } else {
        $salam = 'Night';
    }
?>


<!DOCTYPE html>
<html lang="en">

    <head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Garuda Indonesia</title>

    <!-- Favico<img src="..." class="rounded mx-auto d-block" alt="...">ns -->
    <link href="../assets/img/garudaindonesia.png" rel="icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Template Main CSS File -->
    <link href="../assets/css/style.css" rel="stylesheet">
    </head>

    <body class="d-flex flex-column h-100">

        <!-- ======= Header ======= -->
        <header id="header">
            <div class="container d-flex align-items-center justify-content-between">
            <a href="index.html" class="logo"><img src="../assets/img/logogaruda.png" alt="" class="img-fluid"></a>
            <nav id="navbar" class="navbar">
                <ul>
                <li class="dropdown"><a href="#"><?= $user; ?></a></li>
                    <li><a class="nav-link scrollto active" href="index.php"><span>Dashboard</span><i class="fas fa-tachometer-alt"></i></a></li>
                    <li><a class="nav-link scrollto" href="userdash.php"><span>User</span><i class="fas fa-user"></i></a></li>
                    <li><a class="nav-link scrollto" href="bookdash.php"><span>Booked</span><i class="far fa-calendar-alt"></i></a></li>
                    <li><a class="nav-link scrollto" href="airplanedash.php"><span>Airlines</span><i class="fas fa-plane-departure"></i></a></li>
                    <li><a class="nav-link scrollto" href="tiket.php"><span>Ticket</span><i class="fas fa-ticket"></i></a></li>
                    <li><a class="nav-link scrollto" href="sign_out.php">Sign Out<i class="fas fa-sign-out"></i></a></li>
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
            </nav><!-- .navbar -->
            </div>
        </header><!-- End Header -->
        
        <main id="main" class="mb-5 pb-5 mt-3"> <!--Content -->
            <div class="text-center">
                <p class="fs-3"><?= ' Good '.$salam.' '.$user; ?></p>
            </div>            
            <div class="container mb-3">
                <div class="d-flex justify-content-center">
                    <h3 class="fw-bold">Dashboard Booked</h3>
                </div>
            </div>

            <!-- CARD STATUS-->
            <div class="d-block mx-2 text-white">
                <form action="" method="POST">
                    <div class="input-group ms-5 mb-3 w-25 inline-block">
                        <input type="text" class="form-control" placeholder="Search User">
                        <button type="submit" class="input-group-text btn-info"><i class="bi bi-search"></i></button>
                    </div>
                </form>
                <div class="table-responsive mx-5">
                    <table class="table table-striped caption-top">
                    <div class="d-flex flex-row-reverse bd-highlight">
                        <div class="p-2">
                            <a href="print_airline.php" class="d-flex mb-2">
                                <button type="button" class="btn btn-primary">Print</button>
                            </a>
                        </div>
                        <div class="p-2 bd-highlight">
                            <a href="airplaneadd.php" class="d-flex justify-content-end mb-2">
                                <button type="button" class="btn btn-info">Add</button>
                            </a>
                        </div>
                    </div>
                        
                        
                        <thead class="table-info">
                            <tr>
                                <th>No</th>
                                <th>Airplane Code</th>
                                <th>Type</th>
                                <th>Capacity</th>
                                <th colspan="2" style="text-align: center;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- <tr>
                                <td>1</td>
                                <td>GRD-536</td>
                                <td>Boeing 777</td>
                                <td>50</td>
                                <td>
                                    <a href="">
                                        <button type="button" class="btn btn-success">
                                            <i class="fas fa-pencil"></i>
                                        </button>
                                    </a>
                                    <a href="">
                                        <button type="button" class="btn btn-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </a>
                                </td>
                            </tr> -->
                            <?php
            $no = 1;
            $ambildata = mysqli_query($connect, "select * from table_airplane");
            while ($tampil = mysqli_fetch_array($ambildata)) {
                echo "
                <tr>
                <td>$no</td>
                <td>$tampil[airplane_code]</td>
                <td>$tampil[airplane_type]</td>
                <td>$tampil[capacity]</td>
                <td><a href='edituser.php'><button type='button' class='btn btn-success'>
                <i class='fas fa-pencil'></button></i>
                </td>
                <td><A href='?kode=$tampil[airplane_code]'><button type='button' class='btn btn-danger'>
                <i class='fas fa-trash'></button></i>
                </td>                
                </tr>  
                ";
                $no++;
            }
            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>

    
        <!-- Footer -->
        <footer id="footer" class="bd-footer mt-5 clearfix">
            <div class="fixed-bottom p-3 bg-white d-flex justify-content-center clearfix">
                <div class="copyright ">
                    &copy; Copyright <strong><span>Team 4 MDPL Praktik</span></strong>
                </div>
            </div>
        </footer><!-- End Footer -->


        <!-- Vendor JS Files -->
        <script src="../assets/vendor/purecounter/purecounter.js"></script>
        <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
        <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
        <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
        <script src="../assets/vendor/php-email-form/validate.js"></script>

        <!-- Template Main JS File -->
        <script src="../assets/js/main.js"></script>

    </body>
    <?php
        if (isset($_GET['kode'])) {
            mysqli_query($connect, "delete from table_airplane where airplane_code='$_GET[kode]'");
        
        
            echo "data berhasil dihapus";
            echo "<script language='javascript'>alert('data berhasil dihapus');window.location='airplanedash.php'</script>";
        }
    ?>
    <script type="text/javascript">window.print()</script>

</html>