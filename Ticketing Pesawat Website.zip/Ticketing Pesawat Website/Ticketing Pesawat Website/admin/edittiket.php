<?php
include "session.php";


    //ubah timezone menjadi jakarta
    date_default_timezone_set("Asia/Jakarta");

    $user = "Admin";
    //ambil jam dan menit
    $jam = date('H:i');

    //atur salam menggunakan IF
    if ($jam > '05:30' && $jam < '11:59') {
        $salam = 'Morning';
    } elseif ($jam >= '12:00' && $jam < '17:00') {
        $salam = 'Afternoon';
    } elseif ($jam >= '17:01' && $jam < '20:00') {
        $salam = 'Evening';
    } else {
        $salam = 'Night';
    }

    $game = query("SELECT * FROM table_booking");


    // option bandara
    $planes = array('Boeing 777-300ER','Airbus A330-300','Airbus A330-200','Airbus A330-900neo','Boeing 737 Max 8','BOEING 737-800NG','ATR 72-600');
    

    $bandara = array('JAKARTA (JKTC)', 'SURABAYA (SUBC)', 'MEDAN (MESC)', 'MAKASAR (UPGC)', 'YOGYAKARTA (JOGC)', 'DENPASAR (DPSC)');
?>


<!DOCTYPE html>
<html lang="en">

    <head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Garuda Indonesia</title>

    <!-- Favico<img src="..." class="rounded mx-auto d-block" alt="...">ns -->
    <link href="../assets/img/garudaindonesia.png" rel="icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Template Main CSS File -->
    <link href="../assets/css/style.css" rel="stylesheet">
    </head>

    <body class="d-flex flex-column h-100">
        <div class="container">

            <!-- ======= Header ======= -->
            <header id="header">
                <div class="container d-flex align-items-center justify-content-between">
                <a href="index.html" class="logo"><img src="../assets/img/logogaruda.png" alt="" class="img-fluid"></a>
                <nav id="navbar" class="navbar">
                    <ul>
                    <li class="dropdown"><a href="#"><?= $user; ?></a></li>
                    <li><a class="nav-link scrollto" href="index.php"><span>Dashboard</span><i class="fas fa-tachometer-alt"></i></a></li>
                    <li><a class="nav-link scrollto" href="userdash.php"><span>User</span><i class="fas fa-user"></i></a></li>
                    <li><a class="nav-link scrollto" href="bookdash.php"><span>Booked</span><i class="far fa-calendar-alt"></i></a></li>
                    <li><a class="nav-link scrollto" href="airplanedash.php"><span>Airlines</span><i class="fas fa-plane-departure"></i></a></li>
                    <li><a class="nav-link scrollto active" href="tiket.php"><span>Ticket</span><i class="fas fa-ticket"></i></a></li>
                    <li><a class="nav-link scrollto" href="sign_out.php">Sign Out<i class="fas fa-sign-out"></i></a></li>
                    </ul>
                    <i class="bi bi-list mobile-nav-toggle"></i>
                </nav><!-- .navbar -->
                </div>
            </header><!-- End Header -->
            
            <main class="flex-fill pb-5 mb-5 mt-3"> <!--Content -->
                <div class="text-center">
                    <p class="fs-3"><?= ' Good '.$salam.' '.$user; ?></p>
                </div>                
                <div class="container">
                    <div class="d-flex-inline ">
                        <h3>Edit Tiket</h3>
                    </div>
                    <?php
                    include "koneksi.php";
                    $sql = mysqli_query($connect,"select * from table_tiket where code_tiket='$_GET[kode]'");
                    $data = mysqli_fetch_array($sql);

    
                    ?>
                    <form class="row g-3 needs-validation" method="POST" action="edittiket_p.php">
                        <div class="col-md-4">
                            <label for="depart" class="form-label">Code Ticket</label>
                            <input class="form-control" value="<?php echo $data['code_tiket']; ?>" readonly name="code_tiket" required> 
                        </div>

                        <div class="col-md-4">
                            <label for="depart" class="form-label">Depart</label>
                            <input type="datetime-local" class="form-control" id="depart" name="depart" value="<?php echo $data['depart']; ?>" autocomplete="off" required>
                        </div>

                        <div class="col-md-4">
                            <label for="fromdepart" class="form-label">From</label>
                            <select class="form-select" id="fromdepart" name="bandara_awal"  required>
                            <?PHP foreach($bandara as $b) {?>
                                    <option value="<?php echo $b; ?>"><?php echo $b; ?></option>
                                    <?php } ?>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label for="todepart" class="form-label">To</label>
                            <select class="form-select" id="todepart" name="bandara_tujuan" required>
                            <?PHP foreach($bandara as $b) {?>
                                    <option value="<?php echo $b; ?>"><?php echo $b; ?></option>
                                    <?php } ?>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label for="typeplane" class="form-label">Plane</label>
                            <select class="form-select" id="todepart" name="nama_pesawat"  required>
                            <?PHP foreach($planes as $p) {?>
                                    <option value="<?php echo $p; ?>"><?php echo $p; ?></option>
                                    <?php } ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="classplane" class="form-label">Class</label>
                            <select class="form-select" id="classplane" name="class_penerbangan"  required>
                                <option>Economy</option>
                                <option>Business</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <a href="edittiket_p.php">
                            <button class="btn btn-primary" type="submit">Save</button>

                            </a>
                        </div>
                    </form>
                </div>
            </main>

        <!-- ======= Footer ======= -->
            <footer id="footer" class="bd-footer mt-5 clearfix">
                <div class="fixed-bottom p-3 bg-white d-flex justify-content-center clearfix">
                    <div class="copyright ">
                        &copy; Copyright <strong><span>Team 4 MDPL Praktik</span></strong>
                    </div>
                </div>
            </footer><!-- End Footer -->
        </div>


        <!-- Vendor JS Files -->
        <script src="../assets/vendor/purecounter/purecounter.js"></script>
        <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
        <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
        <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
        <script src="../assets/vendor/php-email-form/validate.js"></script>

        <!-- Template Main JS File -->
        <script src="../assets/js/main.js"></script>

    </body>

</html>