<?php
    include "koneksi.php";

    $code       = $_POST['code_pesawat'];
    $type       = $_POST['type_pesawat'];
    $capacity   = $_POST['capacity'];


    $sql = mysqli_query($connect, 'update table_pesawat set code_pesawat="'.$code.'", type_pesawat="'.$type.'", capacity="'.$capacity.'" where code_pesawat="'.$code.'" ');
    
    if($sql) {
        echo "<script>window.alert('Data berhasil di Edit');window.location.href='airplanedash.php';</script>";
    } else {
        echo "<script>window.alert('Data Gagal');window.close();</script>";
    }
?>