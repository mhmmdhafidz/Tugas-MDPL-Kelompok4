<?php
    include "koneksi.php";

    $code   = $_POST['code_tiket'];
    $depart   = $_POST['depart'];
    $bandara_a  = $_POST['bandara_awal'];
    $bandara_t = $_POST['bandara_tujuan'];
    $name = $_POST['nama_pesawat'];
    $class   = $_POST['class_penerbangan'];

    $sql = mysqli_query($connect, 'update table_tiket set code_tiket="'.$code.'", depart="'.$depart.'", bandara_awal="'.$bandara_a.'", bandara_tujuan="'.$bandara_t.'", nama_pesawat="'.$name.'", class_penerbangan="'.$class.'" where code_tiket="'.$code.'" ');
    
    if($sql) {
        echo "<script>window.alert('Data berhasil di Edit');window.location.href='tiket.php';</script>";
    } else {
        echo "<script>window.alert('Data Gagal');window.close();</script>";
    }
?>