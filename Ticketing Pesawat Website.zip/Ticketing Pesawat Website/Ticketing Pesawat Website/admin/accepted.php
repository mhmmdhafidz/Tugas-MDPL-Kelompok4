<?php
include "koneksi.php";
include "session.php";

$status = 'accepted';

$sql = mysqli_query($connect, 'update table_booking set status="'.$status.'" ');
if($sql) {
    echo "<script>window.alert('Transaksi telah Selesai');window.location.href='bookdash.php';</script>";
} else {
    echo "<script>window.alert('Terjadi ERROR!!');window.location.href='bookdash.php';</script>";
}
?>
