<?php
include "koneksi.php";
session_start();

if(!isset($_SESSION['table_admin']) || empty($_SESSION['table_admin']) ) {
    echo "<script>window.alert('Anda harus Sign In terlebih dahulu!!');window.location.href='sign_in.php';</script>";
}
