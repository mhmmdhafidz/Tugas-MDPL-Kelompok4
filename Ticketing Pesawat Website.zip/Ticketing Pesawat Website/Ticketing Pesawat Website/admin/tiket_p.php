<?php
include "koneksi.php";

$code   = $_POST['code_tiket'];
$depart   = $_POST['depart'];
$bandara_a  = $_POST['bandara_awal'];
$bandara_t = $_POST['bandara_tujuan'];
$name = $_POST['nama_pesawat'];
$class   = $_POST['class_penerbangan'];
$harga  =$_POST['harga'];


$sql    = 'INSERT INTO table_tiket(code_tiket, depart, bandara_awal, bandara_tujuan, nama_pesawat, class_penerbangan, harga) VALUES ("'.$code.'", "'.$depart.'", "'.$bandara_a.'", "'.$bandara_t.'", "'.$name.'", "'.$class.'", "'.$harga.'") ';
$query  = mysqli_query($connect, $sql);

if($query) {
    echo "<script>window.alert('Tiket berhasil ditambahkan'); window.location.href='tiket.php';</script>";
} else {
    echo "<script>window.alert('Oops!!, Terjadi kesalahan!!!'); window.location.href='tiket.php';</script>";
}
?>