<?php
    include "koneksi.php";

    $user = $_POST['username'];
    $full = $_POST['full_name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $gender = $_POST['jenis_kelamin'];
    $sql = mysqli_query($connect, 'update table_user set username="'.$user.'", full_name="'.$full.'", email="'.$email.'", address="'.$address.'", jenis_kelamin="'.$gender.'" where username="'.$user.'" ');
    
    if($sql) {
        echo "<script>window.alert('Data berhasil di Edit');window.location.href='userdash.php';</script>";
    } else {
        echo "<script>window.alert('Data Gagal');window.close();</script>";
    }
?>
