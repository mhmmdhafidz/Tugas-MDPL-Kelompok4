<?php 
	$host = "localhost";
	$username = "root";
	$password = "";
	$db = "ticketing pesawat website";
	$connect = mysqli_connect($host, $username, $password, $db) or die;
?>
