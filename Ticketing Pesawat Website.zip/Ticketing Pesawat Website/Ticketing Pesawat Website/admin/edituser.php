<?php
include "session.php";



    //ubah timezone menjadi jakarta
    date_default_timezone_set("Asia/Jakarta");

    $user = "Crosby";
    //ambil jam dan menit
    $jam = date('H:i');

    //atur salam menggunakan IF
    if ($jam > '05:30' && $jam < '11:59') {
        $salam = 'Morning';
    } elseif ($jam >= '12:00' && $jam < '17:00') {
        $salam = 'Afternoon';
    } elseif ($jam >= '17:01' && $jam < '20:00') {
        $salam = 'Evening';
    } else {
        $salam = 'Night';
    }


?>


<!DOCTYPE html>
<html lang="en">

    <head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Garuda Indonesia</title>

    <!-- Favico<img src="..." class="rounded mx-auto d-block" alt="...">ns -->
    <link href="../assets/img/garudaindonesia.png" rel="icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Template Main CSS File -->
    <link href="../assets/css/style.css" rel="stylesheet">
    </head>

    <body class="d-flex flex-column h-100">

        <!-- ======= Header ======= -->
        <header id="header">
            <div class="container d-flex align-items-center justify-content-between">
            <a href="index.html" class="logo"><img src="assets/img/logogaruda.png" alt="" class="img-fluid"></a>
            <nav id="navbar" class="navbar">
                <ul>
                <li class="dropdown"><a href="#"><?= $user; ?></a></li>
                    <li><a class="nav-link scrollto" href="index.php"><span>Dashboard</span><i class="fas fa-tachometer-alt"></i></a></li>
                    <li><a class="nav-link scrollto active" href="userdash.php"><span>User</span><i class="fas fa-user"></i></a></li>
                    <li><a class="nav-link scrollto" href="bookdash.php"><span>Booked</span><i class="far fa-calendar-alt"></i></a></li>
                    <li><a class="nav-link scrollto" href="airplanedash.php"><span>Airlines</span><i class="fas fa-plane-departure"></i></a></li>
                    <li><a class="nav-link scrollto" href="tiket.php"><span>Ticket</span><i class="fas fa-ticket"></i></a></li>
                    <li><a class="nav-link scrollto" href="sign_out.php">Sign Out<i class="fas fa-sign-out"></i></a></li>
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
            </nav><!-- .navbar -->
            </div>
        </header><!-- End Header -->
        
        <main id="main" class="mt-3 mb-5 pb-5"> <!--Content -->
            <div class="container">
                <div class="d-flex justify-content-center">
                    <p class="fs-3">EDIT PROFILE</p>
                </div>

                <!-- profile section -->
                <div class="container">
                    <div class="col-6 border-2 mb-3">
                    <?php
                    include "koneksi.php";
                    $sql = mysqli_query($connect,"select * from table_user where id_user='$_GET[kode]'");
                    $data = mysqli_fetch_array($sql);

    
                    ?>
                        <img class="img-responsive border border-primary col-4 col-sm-3 rounded-3" src="../assets/img/bg-1.png" alt="">
                    </div>
                    <form class="row g-3 needs-validation" novalidate method="POST" action="edituser_p.php">
                        <div class="col-md-4">
                            <label for="depart" class="form-label">Username</label>
                            <input class="form-control" readonly type="text" value="<?php echo $data['username']; ?>" name="username" required> 
                        </div>

                        <div class="col-md-4">
                            <label for="depart" class="form-label">Fullname</label>
                            <input type="text" class="form-control" value="<?php echo $data['full_name']; ?>" name="full_name" required> 
                        </div>

                        <div class="col-md-4">
                            <label for="depart" class="form-label">Email</label>
                            <input type="text" class="form-control" id="depart" value="<?php echo $data['email']; ?>" name="email" autocomplete="off" required>
                        </div>

                        <div class="col-md-4">
                            <label for="fromdepart" class="form-label">Address</label>
                            <input type="text" class="form-control" id="depart" value="<?php echo $data['address']; ?>" name="address" autocomplete="off" required>
                        </div>
                        <div class="col-md-4">
                            <label for="todepart" class="form-label">Gender</label>
                            <select class="form-select" id="todepart"  name="jenis_kelamin" required>
                                <option value="Men">Men</option>
                                <option value="Women">Women</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <a href="edituser_p.php">
                            <button class="btn btn-primary" type="submit">Save</button>

                            </a>
                        </div>
                    </form>
                </div>
                
            </div>
        </main>

    
        <!-- Footer -->
        <footer id="footer" class="bd-footer mt-5 clearfix">
            <div class="fixed-bottom p-3 bg-white d-flex justify-content-center clearfix">
                <div class="copyright ">
                    &copy; Copyright <strong><span>Team 4 MDPL Praktik</span></strong>
                </div>
            </div>
        </footer><!-- End Footer -->


        <!-- Vendor JS Files -->
        <script src="../assets/vendor/purecounter/purecounter.js"></script>
        <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
        <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
        <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
        <script src="../assets/vendor/php-email-form/validate.js"></script>

        <!-- Template Main JS File -->
        <script src="../assets/js/main.js"></script>
        <script src="../assets/js/showhide.js"></script>
    </body>

</html>