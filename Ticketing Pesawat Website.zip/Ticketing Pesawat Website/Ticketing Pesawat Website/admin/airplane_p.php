<?php
include "koneksi.php";

$kode   = $_POST['code_pesawat'];
$type   = $_POST['type_pesawat'];
$capa   = $_POST['capacity'];


$sql    = 'INSERT INTO table_pesawat(code_pesawat, type_pesawat, capacity) VALUES ("'.$kode.'", "'.$type.'", "'.$capa.'") ';
$query  = mysqli_query($connect, $sql);

if($query) {
    echo "<script>window.alert('Tiket berhasil ditambahkan'); window.location.href='airplanedash.php';</script>";
} else {
    echo "<script>window.alert('Oops!!, Terjadi kesalahan!!!'); window.location.href='airplanedash.php';</script>";
}
?>