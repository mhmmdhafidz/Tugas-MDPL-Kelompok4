<?php

include "session.php";


    //ubah timezone menjadi jakarta
    date_default_timezone_set("Asia/Jakarta");

    $user = "Crosby";
    //ambil jam dan menit
    $jam = date('H:i');

    //atur salam menggunakan IF
    if ($jam > '05:30' && $jam < '11:59') {
        $salam = 'Morning';
    } elseif ($jam >= '12:00' && $jam < '17:00') {
        $salam = 'Afternoon';
    } elseif ($jam >= '17:01' && $jam < '20:00') {
        $salam = 'Evening';
    } else {
        $salam = 'Night';
    }

    require 'function_searchdepart.php';
    $game = query("SELECT * FROM table_tiket");

    if (isset($_POST["search"]) ) {
        $game = search($_POST["key"]);
    }
?>


<!DOCTYPE html>
<html lang="en">

    <head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Garuda Indonesia</title>

    <!-- Favico<img src="..." class="rounded mx-auto d-block" alt="...">ns -->
    <link href="assets/img/garudaindonesia.png" rel="icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
    </head>

    <body class="d-flex flex-column">

    <!-- ======= Header ======= -->
    <header id="header">
    <?php include "koneksi.php";
                    $ss = mysqli_query($connect,'select * from table_user where username="'.$_SESSION['table_user'].'" ');
                    $ds = mysqli_fetch_array($ss);
                    ?>
        <div class="container d-flex align-items-center justify-content-between">
        <a href="index.html" class="logo"><img src="assets/img/logogaruda.png" alt="" class="img-fluid"></a>
        <nav id="navbar" class="navbar">
            <ul>
                <li class="dropdown"><a href="#"><?= $ds['username']; ?></a>
                    <ul>
                        <li><a href="profile.php">Profile<i class="fas fa-user"></i></a></li>
                        <li></i><a class="scrollto" href="sign_out.php">Sign Out<i class="fas fa-sign-out"></i></a></li>
                    </ul>
                </li>
                <li><a class="nav-link scrollto" href="home.php"><span>Home</span><i class="fas fa-home"></i></a></li>
            <li><a class="nav-link scrollto" href="userindex.php"><span>Booked</span><i class="fas fa-book-open"></i></a></li>
            <li><a class="nav-link scrollto" href="cart.php"><span>Cart</span><i class="fas fa-shopping-cart"></i></a></li>
            <li><a class="nav-link scrollto active" href="searchdepart.php"><span>Search Depart</span><i class="fas fa-plane-departure"></i></a></li>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->
        </div>
    </header><!-- End Header -->
    
    <main id="main" class="flex-fill pb-5 mb-5 mt-3"> <!--Content -->
            <div class="text-center">
                <p class="fs-3"><?= ' Good '.$salam.' '.$ds['username']; ?></p>
            </div>

        <!-- main content -->
        <marquee directio="left" scrollamount="15" class="mb-2 mx-lg-5">Selamat, Datang di Website Ticketing Garuda Indonesia Airlines</marquee>
        
        <div class="d-block mx-2 text-white">
            <form action="" method="POST">
                <div class="input-group ms-5 mb-3 w-25 inline-block">
                    <input type="text" id="keyword" name="key" autofocus class="form-control" placeholder="Search Penerbangan">
                    <button type="submit" id="btnsearch" name="search" class="input-group-text btn-info"><i class="bi bi-search"></i></button>
                </div>
            </form>
            <div class="table-responsive mx-5">
                <table class="table table-striped caption-top">
                    <caption class="fw-bold">List Jadwal Penerbangan</caption>
                    <thead class="table-success">
                        <tr>
                            <th>No</th>
                            <th>Depart</th>
                            <th>From</th>
                            <th>To</th>
                            <th>Class</th>
                            <th>Pesawat</th>
                            <th>harga</th>
                            <th>Book</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- <tr>
                            <td>1</td>
                            <td>7-12-2021</td>
                            <td>DIY (YIA)</td>
                            <td>BALI (DPS)</td>
                            <td>Economy</td>
                            <td>Boeing 777-300ER</td>
                            <td>
                                <button type="button" class="btn btn-info">
                                    <i class="fas fa-book-open"></i>
                                </button>
                            </td>
                        </tr> -->
                        <?php $i = 1; ?>
            <?php foreach ($game as $row) :?>
            <tr>
                <td><?= $i ?></td>
                <td><?= $row["depart"]?></td>
                <td><?= $row["bandara_awal"]?></td>
                <td><?= $row["bandara_tujuan"]?></td>
                <td><?= $row["class_penerbangan"]?></td>
                <td><?= $row["nama_pesawat"]?></td>
                <td><?= $row["harga"]?></td>


                
                
                <td>
                    <a href="userindex_edit.php?kode=<?= $row["code_tiket"]; ?>">
                                <button type="button" class="btn btn-info">
                                    <i class="fas fa-book-open"></i>
                                </button>
            </td>
            </tr>
            <?php $i++; ?>
            <?php endforeach;?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    

    <footer id="footer" class="bd-footer mt-5 clearfix">
        <div class="fixed-bottom p-3 bg-white d-flex justify-content-center clearfix">
            <div class="copyright ">
                &copy; Copyright <strong><span>Team 4 MDPL Praktik</span></strong>
            </div>
        </div>
    </footer><!-- End Footer -->

    
    <!-- Vendor JS Files -->
    <script src="assets/vendor/purecounter/purecounter.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>

    </body>

</html>