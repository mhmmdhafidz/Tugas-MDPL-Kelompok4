$(document).ready(function () {
    $("#type").change(function () {
        var val = $(this).val();
        if (val == "item1") {
            $("#size").html("<option value='Rp. 900.000'>Rp. 900.000</option>");
        } else if (val == "item2") {
            $("#size").html("<option value='Rp. 1.700.000'>Rp. 1.700.000</option>");
        } else if (val == "item3");
    });
});