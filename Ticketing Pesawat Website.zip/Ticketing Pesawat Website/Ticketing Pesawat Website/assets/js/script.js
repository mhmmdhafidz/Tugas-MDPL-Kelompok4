// menuliskan jQuery bisa diganti dengan $()
$(document).ready(function () {
    // cara menghilangkan tombol search
    $('#btnsearch').hide();


    // event ketika keyword ditulis
    $('#keyword').on('keyup', function() {
        // munculkan icon loading
        $('.loader').show();

        // ajax menggunakan load karena load methodnya GET
        // $('#container').load('ajax/game.php?keyword='+ $('#keyword').val());

        // $.get()
        $.get('ajax/game.php?keyword='+$('#keyword').val(), function(data) {
            
            $('#container').html(data);
            $('.loader').hide();
        })
    });
});