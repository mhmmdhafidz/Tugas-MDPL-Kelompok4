<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Garuda Airways</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
		<link href="assets/img/garudaindonesia.png" rel="icon">
	</head>
	<body class="bg-info">
		<section class="ftco-section">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-lg-5">
						<img src="assets/img/bg-1.png" class="img-fluid" alt="...">
						<h2 class="text-white text-center mb-4">SIGN UP</h2>

						<form action="sign_up_p.php" method="POST" class="signup-form">
							<div class="input-group mb-3">
								<span class="input-group-text">
									<i class="far fa-user"></i>
								</span>
								<input type="text" class="form-control" name="username" placeholder="Username" autocomplete="off">
							</div>
							<div class="input-group mb-3"> 
								<span class="input-group-text">
									<i class="far fa-id-badge"></i>
								</span>
								<input type="text" class="form-control" placeholder="Full Name" name="full_name" autocomplete="off">
							</div>
							<div class="input-group mb-3">
								<span class="input-group-text">
									<i class="far fa-envelope"></i>
								</span>
								<input type="email" class="form-control" placeholder="Email" name="email" autocomplete="off">
							</div>
							<div class="input-group mb-3">
								<span class="input-group-text">
									<i class="fas fa-map-marked-alt"></i>
								</span>
								<input type="text" class="form-control" placeholder="Address" name="address" autocomplete="off">
							</div>
							<div class="input-group mb-3">
								<span class="input-group-text">
									<i class="fas fa-restroom"></i>
								</span>
								<select class="form-select form-control " name="jenis_kelamin" id="jeniskelamin">
									<option selected>Jenis Kelamin</option>
									<option value="Pria">Pria</option>
									<option value="Wanita">Wanita</option>
								</select>
							</div>
							<div class="input-group mb-3">
								<span class="input-group-text"><i class="fas fa-lock"></i></span>
								<input type="password" class="form-control" id="password" name="password" placeholder="Password" value="">
								<span class="input-group-text">
								<i class="far fa-eye-slash" id="togglePassword" 
									style="cursor: pointer"></i>
								</span>
							</div>
							<div class="form-group mb-3 col-md-5 mx-auto">
								<a href="sign_up_p.php">
								<button type="submit" class="form-control btn btn-primary rounded submit px-3">Sign Up</button>

								</a>
							</div>
							
						</form>
						<p class="text-center">Already have account ? <a class="text-decoration-none text-primary" href="sign_in.php">Sign In</a></p>
					</div>
				</div>
			</div>
		</section>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
		<script src="assets/js/showhide.js"></script>
	</body>
</html>

