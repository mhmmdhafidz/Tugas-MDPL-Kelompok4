<?php 
// koneksi ke database
$connect = mysqli_connect("localhost", "root","", "ticketing pesawat website");





function query($query) {
    global $connect;
    $result = mysqli_query($connect, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result) ) {
        $rows[] = $row;
    }
    return $rows;
}


// function add($data){

//     global $conn;

//     $user      = htmlspecialchars($data["username"]);
//     $full      = htmlspecialchars($data["full_name"]);
//     $email  = htmlspecialchars($data["email"]);
//     $address  = htmlspecialchars($data["address"]);
//     $gender  = htmlspecialchars($data["jenis_kelamin"]);
//     $pass  = htmlspecialchars($data["password"]);

//     // upload image 
//     $image      = upload();
//     if ( !$image ) {
//         return false;
//     }

//     // query insert data
//     $query = "INSERT INTO game
//             VALUES
//             ('', '$user', '$full','$email','$address','$gender', '$pass')
//             ";
//     mysqli_query($conn, $query);
//     return mysqli_affected_rows($conn);

// }

function upload() {
    
    $filename = $_FILES['image']['name'];
    $size = $_FILES['image']['size'];
    $error = $_FILES['image']['error'];
    $tmpname = $_FILES['image']['tmp_name'];


    // cek apakah tidak ada gambar yang diupload
    if ( $error === 4 ) {
        echo "<script> alert('choose image'); </script>";
        return false;
    }

    // cek apakah yang diupload adalah image/gambar

    // array gambar ekstensi
    $extentionvalidimage = ['jpg','png','jpeg'];
    // dipecah antara nama dan ektensi delimiternya .
    $extentionimage      = explode('.', $filename);

    // setelah dipecah tadi diambil nama yang terakhir dan diforce huruf kecil semua
    $extentionimage      = strtolower(end($extentionimage));

    // cek apakah file adalah beripe gambar atau bukan
    if ( !in_array($extentionimage, $extentionvalidimage) ) {
        echo "<script> alert('not a image please try again'); </script>";
        return false;
    }


    // cek jika ukuran file terlalu besar
    if ($size > 1000000) {
        echo "<script> alert('file is oversize'); </script>";
        return false;
    }

    // lolos checking , gambar siap diupload
    // generate nama gambar baru
    $newnamefile  = uniqid();
    $newnamefile .= '.';
    $newnamefile .= $extentionimage;
    move_uploaded_file($tmpname, 'img/'.$newnamefile);

    return $newnamefile;
}



// function del($id) {
//     global $conn;
//     mysqli_query($conn, "DELETE FROM game WHERE id = $id");

//     return mysqli_affected_rows($conn);
// }


function update($data) {
    global $connect;
    
    $id         = $data["id_user"];
    $user       = htmlspecialchars($data["username"]);
    $full       = htmlspecialchars($data["full_name"]);
    $email      = htmlspecialchars($data["email"]);
    $address    = htmlspecialchars($data["address"]);
    $gender     = htmlspecialchars($data["jenis_kelamin"]);
    $pass       = htmlspecialchars($data["password"]);
    $oldimage   = htmlspecialchars($data["oldimage"]);
    $image      = htmlspecialchars($data["image"]);

    // check apakah user pilih gambar baru atau tidak
    if ($_FILES['image']['error'] === 4) {
        $image = $oldimage;
    } else {
        $image = upload();
    }


    // query insert data
    $query = "UPDATE table_user SET 
                username        = '$user',
                full_name       = '$full',
                email           = '$email',
                address         = '$address',
                jenis_kelamin   = '$gender',
                password        = '$pass',
                image           = '$image'
                WHERE id_user   = $id 
            ";

    mysqli_query($connect, $query);

    return mysqli_affected_rows($connect);
}


// function search($key){
//     $query = "SELECT * FROM game
//                 WHERE
//                 -- LIKE berguna untuk mencari data bisa nama depan, huruf , bebas
//                 title LIKE '%$key%' OR
//                 genre LIKE '%$key%' OR
//                 developer LIKE '%$key%' OR
//                 publisher LIKE '%$key%' 
//             ";

//     return query($query);
// }


// function registrasi($data){
//     global $conn;

//     $username = strtolower(stripslashes($data["username"]));
//     $password = mysqli_real_escape_string($conn, $data["password"]);
//     $repass   = mysqli_real_escape_string($conn, $data["repass"]);

//     // cek username ada apa belum
//     $result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username' ");

//     if (mysqli_fetch_assoc($result)) {
//         echo "<script> alert('username sudah terdaftar'); </script>";
//         return false;
//     }


//     // cek konfirmasi password
//     if ($password !== $repass ) {
//         echo "<script>
//             alert('konfirmasi password tidak sesuai');
//         </script>";
//         return false;
//     }
//     // enkripsi password
//     $password = password_hash($password, PASSWORD_DEFAULT);
    
//     // tambahkan userbaru ke databse
//     mysqli_query($conn, "INSERT INTO user VALUES('','$username','$password')");
//     return mysqli_affected_rows($conn);
// }

?>