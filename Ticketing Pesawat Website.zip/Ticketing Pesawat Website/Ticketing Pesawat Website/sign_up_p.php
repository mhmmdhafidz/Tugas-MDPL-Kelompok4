<?php
include "koneksi.php";

$user   = $_POST['username'];
$full   = $_POST['full_name'];
$email  = $_POST['email'];
$address = $_POST['address'];
$gender = $_POST['jenis_kelamin'];
$pass   = $_POST['password'];

$sql    = 'INSERT INTO table_user(username, full_name, email, address, jenis_kelamin, password) VALUES ("'.$user.'", "'.$full.'", "'.$email.'", "'.$address.'", "'.$gender.'", "'.$pass.'") ';
$query  = mysqli_query($connect, $sql);

if($query) {
    echo "<script>window.alert('Selamat, Akun anda berhasil dibuat'); window.location.href='sign_in.php';</script>";
} else {
    echo "<script>window.alert('Oops!!, Terjadi kesalahan!!!'); window.location.href='sign_up.php';</script>";
}
?>