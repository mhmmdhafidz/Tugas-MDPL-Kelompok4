<?php 
include "koneksi.php";


function query($query) {
    global $connect;
    $result = mysqli_query($connect, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result) ) {
        $rows[] = $row;
    }
    return $rows;
}


// function add($data){

//     global $connect;

//     $title      = htmlspecialchars($data["title"]);
//     $genre      = htmlspecialchars($data["genre"]);
//     $publisher  = htmlspecialchars($data["publisher"]);
//     $developer  = htmlspecialchars($data["developer"]);

//     // upload image 
//     $image      = upload();
//     if ( !$image ) {
//         return false;
//     }

//     // query insert data
//     $query = "INSERT INTO table_user
//               VALUES
//               ('', '$title', '$genre','$developer','$publisher','$image')
//               ";
//     mysqli_query($connect, $query);
//     return mysqli_affected_rows($connect);

// }

// function upload() {
    
//     $filename = $_FILES['image']['name'];
//     $size = $_FILES['image']['size'];
//     $error = $_FILES['image']['error'];
//     $tmpname = $_FILES['image']['tmp_name'];


//     // cek apakah tidak ada gambar yang diupload
//     if ( $error === 4 ) {
//         echo "<script> alert('choose image'); </script>";
//         return false;
//     }

//     // cek apakah yang diupload adalah image/gambar
//     $extentionvalidimage = ['jpg','png','jpeg'];
//     $extentionimage      = explode('.', $filename);
//     $extentionimage      = strtolower(end($extentionimage));
//     if ( !in_array($extentionimage, $extentionvalidimage) ) {
//         echo "<script> alert('not a image please try again'); </script>";
//         return false;
//     }


//     // cek jika ukuran file terlalu besar
//     if ($size > 25000000) {
//         echo "<script> alert('file is oversize'); </script>";
//         return false;
//     }

//     // lolos checking , gambar siap diupload
//     // generate nama gambar baru
//     $newnamefile  = uniqid();
//     $newnamefile .= '.';
//     $newnamefile .= $extentionimage;

//     move_uploaded_file($tmpname, 'assets/img/'.$newnamefile);

//     return $filename;
// }



// function del($id) {
//     global $conn;
//     mysqli_query($conn, "DELETE FROM game WHERE id = $id");

//     return mysqli_affected_rows($conn);
// }


// function update($data) {
//     global $conn;
    
//     $id         = $data["id"];
//     $title      = htmlspecialchars($data["title"]);
//     $genre      = htmlspecialchars($data["genre"]);
//     $publisher  = htmlspecialchars($data["publisher"]);
//     $developer  = htmlspecialchars($data["developer"]);
//     $oldimage   = htmlspecialchars($data["oldimage"]);
//     $image      = htmlspecialchars($data["image"]);

    // check apakah user pilih gambar baru atau tidak
    // if ($_FILES['image']['error'] === 4) {
    //     $image = $oldimage;
    // } else {
    //     $image = upload();
    // }


    // query insert data
//     $query = "UPDATE game SET 
//                 title       ='$title',
//                 genre       = '$genre',
//                 developer   = '$developer',
//                 publisher   = '$publisher',
//                 image      = '$image'
//             WHERE id = $id 
//             ";

//     mysqli_query($conn, $query);

//     return mysqli_affected_rows($conn);
// }


function search($key){
    $query = "SELECT * FROM table_user
                WHERE
                -- LIKE berguna untuk mencari data bisa nama depan, huruf , bebas
                username LIKE '%$key%' OR
                full_name LIKE '%$key%' OR
                email LIKE '%$key%' OR
                jenis_kelamin LIKE '%$key%' OR
                address LIKE '%$key%' 
            ";

    return query($query);
}


// function registrasi($data){
//     global $conn;

//     $username = strtolower(stripslashes($data["username"]));
//     $password = mysqli_real_escape_string($conn, $data["password"]);
//     $repass   = mysqli_real_escape_string($conn, $data["repass"]);

//     // cek username ada apa belum
//     $result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username' ");

//     if (mysqli_fetch_assoc($result)) {
//         echo "<script> alert('username sudah terdaftar'); </script>";
//         return false;
//     }


    // cek konfirmasi password
    // if ($password !== $repass ) {
    //     echo "<script>
    //         alert('konfirmasi password tidak sesuai');
    //     </script>";
    //     return false;
    // }
    // // enkripsi password
    // $password = password_hash($password, PASSWORD_DEFAULT);
    
    // // tambahkan userbaru ke databse
    // mysqli_query($conn, "INSERT INTO user VALUES('','$username','$password')");
    // return mysqli_affected_rows($conn);
// }

?>