-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 12 Des 2021 pada 14.34
-- Versi server: 10.4.21-MariaDB
-- Versi PHP: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ticketing pesawat website`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_admin`
--

CREATE TABLE `table_admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `table_admin`
--

INSERT INTO `table_admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_booking`
--

CREATE TABLE `table_booking` (
  `id_booking` int(10) NOT NULL,
  `code_tiket` varchar(10) NOT NULL,
  `waktu_booking` varchar(30) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `waktu_berangkat` varchar(30) NOT NULL,
  `bandara_awal` varchar(30) NOT NULL,
  `bandara_tujuan` varchar(30) NOT NULL,
  `nama_pesawat` varchar(35) NOT NULL,
  `class_penerbangan` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `harga` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `table_booking`
--

INSERT INTO `table_booking` (`id_booking`, `code_tiket`, `waktu_booking`, `full_name`, `waktu_berangkat`, `bandara_awal`, `bandara_tujuan`, `nama_pesawat`, `class_penerbangan`, `status`, `harga`) VALUES
(40, '2021-12-16', 'Wednesday,08 Dec 2021 01:32pm', 'tegar rangga', '', 'MEDAN (MESC)', 'YOGYAKARTA (JOGC)', 'Boeing 737 Max 8', 'Business', 'refused', ''),
(41, 'J8HQM3WQ', 'Wednesday,08 Dec 2021 01:45pm', 'ristu aji', '2021-12-09T15:50', 'YOGYAKARTA (JOGC)', 'DENPASAR (DPSC)', 'ATR 72-600', 'Business', 'accepted', ''),
(43, 'KJWAHMJB', 'Sunday,12 Dec 2021 08:19pm', 'yyyy', '2021-12-09T20:21', 'MEDAN (MESC)', 'JAKARTA (JKTC)', 'Airbus A330-900neo', 'item2', 'Proses', 'Rp. 1.700.000<'),
(44, '3FO80SM4', 'Sunday,12 Dec 2021 08:20pm', '', '', 'JAKARTA (JKTC)', 'JAKARTA (JKTC)', 'ATR 72-600', 'item2', 'Proses', ''),
(45, 'QFDRBZJ2', 'Sunday,12 Dec 2021 08:29pm', 'tttt', '2022-01-01T20:35', 'SURABAYA (SUBC)', 'JAKARTA (JKTC)', 'ATR 72-600', 'item2', 'Proses', 'Rp. 1.700.000<');

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_pesawat`
--

CREATE TABLE `table_pesawat` (
  `id_pesawat` int(10) NOT NULL,
  `code_pesawat` varchar(35) NOT NULL,
  `type_pesawat` varchar(35) NOT NULL,
  `capacity` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `table_pesawat`
--

INSERT INTO `table_pesawat` (`id_pesawat`, `code_pesawat`, `type_pesawat`, `capacity`) VALUES
(5, '777-300ER', 'Boeing', '4501'),
(6, 'A330-300', 'Airbus', '255'),
(7, 'A330-200', 'Airbus', '225'),
(8, 'A330-900neo', 'Airbus', '310'),
(9, '737 Max 8', 'Boeing', '180'),
(11, '72-600', 'ATR', '70');

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_tiket`
--

CREATE TABLE `table_tiket` (
  `id_tiket` int(10) NOT NULL,
  `code_tiket` varchar(20) NOT NULL,
  `depart` date NOT NULL,
  `bandara_awal` varchar(20) NOT NULL,
  `bandara_tujuan` varchar(20) NOT NULL,
  `nama_pesawat` varchar(35) NOT NULL,
  `class_penerbangan` varchar(30) NOT NULL,
  `harga` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `table_tiket`
--

INSERT INTO `table_tiket` (`id_tiket`, `code_tiket`, `depart`, `bandara_awal`, `bandara_tujuan`, `nama_pesawat`, `class_penerbangan`, `harga`) VALUES
(15, 'MHK0WJ20', '2021-12-11', 'JAKARTA (JKTC)', 'MAKASAR (UPGC)', 'Boeing 777-300ER', 'Business', 'Rp.1.200.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_user`
--

CREATE TABLE `table_user` (
  `id_user` int(10) NOT NULL,
  `username` varchar(25) NOT NULL,
  `full_name` varchar(35) NOT NULL,
  `email` varchar(35) NOT NULL,
  `address` varchar(200) NOT NULL,
  `jenis_kelamin` varchar(35) NOT NULL,
  `password` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `table_user`
--

INSERT INTO `table_user` (`id_user`, `username`, `full_name`, `email`, `address`, `jenis_kelamin`, `password`) VALUES
(9, 'user1', 'user', 'user@gmail.com', 'yogyakarta', 'Pria', 'user1'),
(10, 'user2', 'useruser', 'user2@gmail.com', 'yogyakarta', 'Women', '123');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `table_booking`
--
ALTER TABLE `table_booking`
  ADD PRIMARY KEY (`id_booking`);

--
-- Indeks untuk tabel `table_pesawat`
--
ALTER TABLE `table_pesawat`
  ADD PRIMARY KEY (`id_pesawat`);

--
-- Indeks untuk tabel `table_tiket`
--
ALTER TABLE `table_tiket`
  ADD PRIMARY KEY (`id_tiket`);

--
-- Indeks untuk tabel `table_user`
--
ALTER TABLE `table_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `table_booking`
--
ALTER TABLE `table_booking`
  MODIFY `id_booking` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT untuk tabel `table_pesawat`
--
ALTER TABLE `table_pesawat`
  MODIFY `id_pesawat` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `table_tiket`
--
ALTER TABLE `table_tiket`
  MODIFY `id_tiket` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `table_user`
--
ALTER TABLE `table_user`
  MODIFY `id_user` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
